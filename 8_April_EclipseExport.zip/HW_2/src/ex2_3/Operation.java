package ex2_3;

public enum Operation {
	ADDITION, SUBSTRAKTION, MULTIPLIKATION, LUCAS
}
