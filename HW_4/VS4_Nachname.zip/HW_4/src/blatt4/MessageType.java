package blatt4;

public enum MessageType {
	EXCHANGE, SEARCH, INFO;
}
